#include <iostream>
using namespace std;

int main() {
    long long degree;
    cin >> degree;
    
    cout << "25" << endl;
    
    return 0;
}

